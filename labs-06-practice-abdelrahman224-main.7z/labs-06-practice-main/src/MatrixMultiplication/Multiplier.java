package MatrixMultiplication;

import java.util.List;

public class Multiplier {
    
    public static void multiply(double[][] matrix1, double[][] matrix2, double[][] result){
            for (int row = 0; row < result.length; row++) {
        for (int col = 0; col < result[row].length; col++) {
            result[row][col] = multiplyMatricesCell(matrix1, matrix2, row, col);
        }
        }
    };
    
    protected static void waitForThreads(List<Thread> threads) {
        throw new UnsupportedOperationException("No implementation for waitForThreads write your own implementatio");
    }
    
    protected static double multiplyMatricesCell(double[][] firstMatrix, double[][] secondMatrix, int row, int col) {
    double cell = 0;
    for (int i = 0; i < secondMatrix.length; i++) {
        cell += firstMatrix[row][i] * secondMatrix[i][col];
    }
    return cell;
}
}
